# Eye-Blink-Attendance
A simple python project for Eye Blink Detection and Face Recognition based attendance system.

